import sympy as sp
import random
import json
from scipy.constants import hbar, c

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in high energy physics
E, m = sp.symbols('E m')  # energy, mass

# 3. Generate Random Parameters Function
def generate_random_parameters_high_energy_physics():
    return {
        'm': random.uniform(0.1, 10)  # mass in GeV/c^2
    }

# 4. Problem Templates and Solutions
def high_energy_physics_problem():
    params = generate_random_parameters_high_energy_physics()

    # The energy of a particle formula based on Einstein's mass-energy equivalence
    E_expr = m * c**2

    # Generate the problem statement
    instruction = ("一个粒子的质量是 {m:.2f} GeV/c^2。计算这个粒子的能量。").format(m=params['m'])

    # Solve the problem symbolically
    energy = E_expr.evalf(subs={m: params['m'], c: 1})  # set speed of light c to 1 as it's used in natural units in high energy physics

    output = ("这个问题涉及到高能物理中的粒子能量计算。粒子的能量可以通过使用爱因斯坦的质能等价公式 E = mc^2 来计算。"
              "在高能物理中，我们通常使用自然单位制，其中光速 c = 1。"
              "在这个特定的问题中，我们要计算的粒子的质量 m = {m:.2f} GeV/c^2，"
              "插入这个质量值到质能等价公式，我们得到的能量结果是 E ≈ mc^2 = {m:.2f} * (1)^2 = {E:.2f} GeV."
              "因此，这个粒子的能量大约是 {E:.2f} GeV。了解粒子的能量对于分析粒子相互作用、理解基本粒子性质等高能物理问题十分重要。"
              ).format(m=params['m'], E=energy)

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = high_energy_physics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('HEP2.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} high energy physics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()