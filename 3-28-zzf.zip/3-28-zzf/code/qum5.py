import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in Feynman diagrams and interaction probabilities
g, E, p_initial, p_final = sp.symbols('g E p_initial p_final')  # coupling constant, energy, initial and final momenta

# 3. Generate Random Parameters Function
def generate_random_parameters_qft():
    return {
        'g': random.uniform(0.1, 1.5),           # dimensionless coupling constant
        'E': random.uniform(1.0, 100.0),         # energy in GeV
        'p_initial': random.uniform(0.1, 10.0),  # initial momentum in GeV/c
        'p_final': random.uniform(0.1, 10.0)    # final momentum in GeV/c
    }

# 4. Problem Templates and Solutions
def qft_interaction_problem():
    params = generate_random_parameters_qft()

    # Interaction probability amplitude from a Feynman diagram
    M = sp.simplify(g**2 / (E**2 - (p_initial - p_final)**2))

    # Generate the problem statement
    instruction = ("考虑一个简单的费曼图描述的粒子散射过程，其中耦合常数为g，初始动量为p_initial，最终动量为p_final。"
                   "已知耦合常数g = {g:.2f}，初始动量p_initial = {p_initial:.2f} GeV/c，"
                   "最终动量p_final = {p_final:.2f} GeV/c。"
                   "给出这个过程的总能量E = {E:.2f} GeV，计算相互作用的概率振幅M。").format(
                       g=params['g'], E=params['E'],
                       p_initial=params['p_initial'], p_final=params['p_final'])

    # Solve the problem symbolically
    interaction_amplitude = M.evalf(subs=params)

    output = "这个问题涉及到量子场论中的费曼图和粒子相互作用概率振幅的计算。" \
        "相互作用的概率振幅M可以通过费曼规则得出的公式 M = g² / (E² - (p_initial - p_final)²) 来计算。" \
        "其中：- g 表示耦合常数，- E 表示总能量，- p_initial 和 p_final 分别表示初始和最终的动量。" \
        f"在这个特定的问题中，给定的条件是耦合常数g = {params['g']:.2f}，" \
        f"总能量E = {params['E']:.2f} GeV，初始动量p_initial = {params['p_initial']:.2f} GeV/c，最终动量p_final = {params['p_final']:.2f} GeV/c，" \
        f"我们可以计算出相互作用概率振幅M的值为 M ≈ {interaction_amplitude:.2e}。" \
        "了解这种概率振幅对于预测粒子散射过程中发生的相互作用的可能性至关重要。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 10  # Number of problems to generate, adjust as needed
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = qft_interaction_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a json file
    with open('qum5.json', 'w', encoding='utf-8') as f:
        json.dump(problems_and_solutions, f, ensure_ascii=False, indent=4)

    print(f"Generated {num_problems} quantum field theory interaction problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()