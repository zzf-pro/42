import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in nanotechnology
a, ρ, m = sp.symbols('a ρ m')  # edge length of nanoparticle, density of material, mass

# 3. Generate Random Parameters Function
def generate_random_parameters_nanotech():
    return {
        'a': random.uniform(1, 100),  # edge length in nanometers (size of nanoparticle)
        'ρ': random.uniform(1, 22) * 10**3  # density in kg/m^3 (approximation for metals)
    }

# 4. Problem Templates and Solutions
def nanotech_problem():
    params = generate_random_parameters_nanotech()

    # Convert nanometers to meters
    a_m = params['a'] * 10**-9

    # The volume of a nanoparticle (cube) formula
    V_expr = a_m**3

    # The mass of a nanoparticle formula
    m_expr = ρ * V_expr

    # Generate the problem statement
    instruction = ("一个立方体纳米粒子的边长为 {a:.2f} 纳米，金属的密度为 {ρ:.2f} kg/m³。"
                   "计算这个纳米粒子的质量。").format(a=params['a'], ρ=params['ρ'])

    # Solve the problem symbolically
    mass = m_expr.evalf(subs={a: a_m, ρ: params['ρ']})

    output = "这个问题涉及到纳米技术中的纳米粒子质量计算，它是研究纳米材料的重要工具。" \
        "纳米粒子的质量可以通过公式 m = ρ × V 计算。" \
        "其中：- ρ 表示材料的密度，- a 表示立方体纳米粒子的边长。" \
        f"在这个特定的问题中，我们需要计算质量 m。根据上述公式，给定的条件是纳米粒子的边长 a = {params['a']:.2f} 纳米，材料的密度 ρ = {params['ρ']:.2f} kg/m³，" \
        f"我们可以得出纳米粒子的质量的值是 m ≈ {mass:.2e} kg。" \
        "此外，理解纳米粒子的质量对于纳米技术的应用至关重要，例如在药物输送、催化剂、电子设备等方面，纳米粒子的质量直接影响其性能和效果。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000  # Change number of problems as needed
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = nanotech_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('nan5.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} nanotechnology problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()