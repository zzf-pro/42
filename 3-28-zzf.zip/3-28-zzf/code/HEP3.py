import sympy as sp
import random
import json
from scipy.constants import c

# 1. Import Necessary Libraries

# 2. Define Symbols
E, m = sp.symbols('E m')  # energy, mass

# 3. Generate Random Parameters Function
def generate_random_parameters_high_energy_physics():
    return {
        'm': random.uniform(1e+29, 1e+30)  # mass in kg
    }

# 4. Problem Templates and Solutions
def high_energy_physics_problem():
    params = generate_random_parameters_high_energy_physics()

    # The energy of a particle formula based on Einstein's mass-energy equivalence
    E_expr = m * c**2

    # Generate the problem statement
    instruction = ("在一个核反应中，一个质量为 {m:.2e} kg 的粒子。计算这个粒子的能量。").format(m=params['m'])

    # Solve the problem symbolically
    energy = E_expr.evalf(subs={m: params['m'], c: c})  # here, it is meaningful to use the value of speed of light c in m/s

    output = ("这个问题涉及到高能物理中的质能等价。质能等价是描述质量与能量之间关系的物理定律，它是研究粒子物理和核物理的重要工具。"
              "质量与能量之间的关系由爱因斯坦的著名公式 E=mc^2 来，其中："
              "- m 表示粒子的质量，"
              "- c 表示光速。"
              "在这个特定的问题中，我们需要计算核反应中粒子的能量 E。已知粒子的质量 m = {m:.2e} kg 和光速 c = {c} m/s，"
              "插入这个质量值到质能等价公式，计算出的能量结果是 E ≈ {E:.2e} J。"
              "因此，这个粒子的能量大约是 {E:.2e} 焦耳。核反应中能量的计算对于分析核反应机制、预测反应结果等高能物理问题具有重要意义。"
              ).format(m=params['m'], c=c, E=energy)

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 100
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = high_energy_physics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('HEP3.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} high-energy physics problems and solutions.")

# 6. Execution
if __name__ == "__main__":
    main()