import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for scattering cross section calculation in quantum field theory
σ, g, s = sp.symbols('σ g s')  # scattering cross section, coupling constant, center-of-mass energy squared

# 3. Generate Random Parameters Function
def generate_random_parameters_qft():
    return {
        'g': random.uniform(0.1, 2.0),   # dimensionless coupling constant
        's': random.uniform(1.0, 10.0)  # center-of-mass energy squared in GeV^2
    }

# 4. Problem Templates and Solutions
def qft_scattering_problem():
    params = generate_random_parameters_qft()

    # Formula for the scattering cross section based on a simple model
    σ_expr = (g**4) / (64 * sp.pi * s)

    # Generate the problem statement
    instruction = ("在量子场论中，考虑一个简单模型，其中两个粒子的散射截面σ可以用耦合常数g和质心系能量平方s来表示。"
                   "给定耦合常数g = {g:.2f} 和质心系能量平方s = {s:.2f} GeV^2，计算散射截面σ。").format(
                       g=params['g'], s=params['s'])

    # Solve the problem symbolically
    scattering_cross_section = σ_expr.evalf(subs=params)

    output = "这个问题涉及到量子场论中的散射截面计算，它是描述粒子散射过程的一个重要量。" \
        "散射截面σ可以通过公式 σ = g⁴ / (64πs) 来计算。" \
        "其中：- g 表示耦合常数，- s 表示质心系能量平方。" \
        f"在这个特定的问题中，给定的条件是耦合常数g = {params['g']:.2f}，质心系能量平方s = {params['s']:.2f} GeV^2，" \
        f"我们可以计算出散射截面σ的值为 σ ≈ {scattering_cross_section:.2e} GeV⁻²。" \
        "散射截面的大小可以帮助我们了解在高能物理实验中粒子间相互作用的强弱，也是探测和研究新粒子性质的关键指标。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 10  # Number of problems to generate, adjust as needed
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = qft_scattering_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a json file
    with open('qum3.json', 'w', encoding='utf-8') as f:
        json.dump(problems_and_solutions, f, ensure_ascii=False, indent=4)

    print(f"Generated {num_problems} quantum field theory scattering problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()