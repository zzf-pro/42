import sympy as sp
import random
import json
from scipy.constants import hbar, c

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in quantum field theory
E, p, m = sp.symbols('E p m')  # energy, momentum, mass


# 3. Generate Random Parameters Function
def generate_random_parameters_qft():
    return {
        'p': random.uniform(-1e-19, 1e-19),  # momentum in kg*m/s (for elementary particles)
        'm': random.uniform(0.1, 5)  # mass in eV/c^2 (rest mass of elementary particles)
    }


# 4. Problem Templates and Solutions
def qft_problem():
    params = generate_random_parameters_qft()

    # The energy-momentum relation in quantum field theory
    E_expr = sp.sqrt(p**2 * c**2 + m**2 * c**4)

    # Generate the problem statement
    instruction = ("一个静止质量为 {m:.2f} eV/c² 的粒子，其动量为 {p:.2e} kg*m/s。"
                   "使用量子场论中的能量-动量关系计算这个粒子的总能量。").format(m=params['m'], p=params['p'])

    # Solve the problem symbolically
    energy = E_expr.evalf(subs={p: params['p']*c, m: params['m']*c**2/hbar})

    output = "这个问题涉及到量子场论中的能量-动量关系，它是粒子物理学中描述粒子性质的基本工具。" \
        "粒子的总能量可以通过公式 E = √(p²c² + m²c⁴) 计算。" \
        "其中：- p 表示粒子的动量，- m 表示粒子的静止质量。" \
        f"在这个特定的问题中，我们需要计算总能量 E。根据上述公式，给定的条件是动量 p = {params['p']:.2e} kg*m/s，静止质量 m = {params['m']:.2f} eV/c²，" \
        f"我们可以得出总能量的值是 E ≈ √({params['p']:.2e}²c² + ({params['m']:.2f}c²/hbar)²) ≈ {energy:.2e} J。" \
        f"所以，这个粒子的总能量大约是 {energy:.2e} 焦耳。此外，了解粒子的总能量有助于我们理解粒子的行为和相互作用，" \
        "也对高能物理实验和宇宙学研究等领域有着重要的应用。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = qft_problem()
        problems_and_solutions.append(problem)
    i=0
    # Save problems and solutions into a jsonl file
    with open('qum1.jsonl', 'w', encoding='utf-8') as f:
            for item in problems_and_solutions:
                i += 1
                if i != 1000:
                    f.write(json.dumps(item, ensure_ascii=False) + ',\n')
                else:
                    f.write(json.dumps(item, ensure_ascii=False))

    print(f"Generated {num_problems} quantum field theory problems and solutions.")


# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()