import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for the Henon map
x, y, a, b = sp.symbols('x y a b')  # state variables and parameters

# 3. Generate Random Parameters Function
def generate_random_parameters_henon_map():
    return {
        'x0': random.uniform(-1.5, 1.5),  # initial condition for state variable x
        'y0': random.uniform(-0.5, 0.5),  # initial condition for state variable y
        'a': random.uniform(1.2, 1.4),    # parameter 'a' in the Henon map
        'b': random.uniform(0.2, 0.4)     # parameter 'b' in the Henon map
    }

# 4. Problem Templates and Solutions
def henon_map_problem():
    params = generate_random_parameters_henon_map()

    # Henon map formulas
    henon_map_expr_x = 1 - a * x**2 + y
    henon_map_expr_y = b * x

    # Generate the problem statement
    instruction = ("Consider the Henon map with parameters a = {a:.2f} and b = {b:.2f}. "
                   "Given the initial conditions x0 = {x0:.2f} and y0 = {y0:.2f}, "
                   "calculate the next state (x1, y1).").format(
                       x0=params['x0'], y0=params['y0'], a=params['a'], b=params['b'])

    # Solve the problem symbolically
    next_state_x = henon_map_expr_x.subs({x: params['x0'], y: params['y0'], a: params['a'], b: params['b']}).evalf()
    next_state_y = henon_map_expr_y.subs({x: params['x0'], y: params['y0'], a: params['a'], b: params['b']}).evalf()

    output = ("The Henon map is a discrete-time dynamical system that exhibits chaotic behavior. "
              "For the given parameters and initial conditions, the next state of the system is "
              "(x1, y1) = ({x1:.2f}, {y1:.2f}).").format(
                  x1=next_state_x, y1=next_state_y)

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = henon_map_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('ND5.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} Henon map problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()