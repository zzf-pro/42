import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in materials science
E, σ, ε = sp.symbols('E σ ε')  # Young's modulus, stress, strain

# 3. Generate Random Parameters Function
def generate_random_parameters_materials():
    return {
        'E': random.uniform(1e9, 1e12),  # Young's modulus in Pascals (typical range for materials)
        'σ': random.uniform(1e6, 1e9)  # stress in Pascals (typical range for materials)
    }

# ...
# 4. Problem Templates and Solutions
def materials_problem():
    params = generate_random_parameters_materials()

    # The stress-strain relationship formula (Hooke's Law)
    ε_expr = σ / E

    # Generate the problem statement
    instruction = ("A material is subjected to a stress of {σ:.2e} Pa. Given that the material's "
                   "Young's modulus is {E:.2e} Pa, calculate the resulting strain.").format(σ=params['σ'], E=params['E'])

    # Solve the problem symbolically
    strain = ε_expr.evalf(subs=params)

    output = "This problem involves the calculation of strain in the field of materials science, " \
        "which is crucial for understanding the mechanical behavior of materials. " \
        "Strain is the deformation per unit length of a material. The physical quantity can be calculated using the formula ε = σ / E. " \
        "Here: - E represents Young's modulus, - σ represents the stress applied to the material. " \
        f"In this particular problem, given the stress σ = {params['σ']:.2e} Pa and Young's modulus E = {params['E']:.2e} Pa, " \
        f"the strain can be calculated as ε ≈ {params['σ']:.2e} / {params['E']:.2e} ≈ {strain:.2e}. " \
        f"Therefore, the resulting strain is approximately {strain:.2e}. Understanding strain is important for predicting how materials will behave under various loads, " \
        "which has significant applications in engineering design, construction, and materials science research."

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }
# ...

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = materials_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('MSE1.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} materials science problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()