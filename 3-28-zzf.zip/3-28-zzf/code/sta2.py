import sympy as sp
import random
import json
from scipy.constants import k, pi, h

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in statistical mechanics
N1, N2, T, V, m1, m2, U, S, v_avg = sp.symbols('N1 N2 T V m1 m2 U S v_avg')

# 3. Generate Random Parameters Function
def generate_random_parameters_stat_mech():
    return {
        'N1': random.randint(1, 10**23),  # number of particles for component 1
        'N2': random.randint(1, 10**23),  # number of particles for component 2
        'T': random.uniform(100, 500),  # temperature in Kelvin
        'V': random.uniform(0.1, 10.0),  # volume in cubic meters
        'm1': random.uniform(1.0e-27, 5.0e-26),  # mass of particles for component 1 in kg
        'm2': random.uniform(1.0e-27, 5.0e-26),  # mass of particles for component 2 in kg
    }

# 4. Problem Templates and Solutions
def stat_mech_problem():
    params = generate_random_parameters_stat_mech()

    # Internal energy of an ideal gas mixture formula
    U_expr = (3/2) * (N1 + N2) * k * T

    # Average velocity for component 1 using Maxwell-Boltzmann distribution
    v_avg_expr = sp.sqrt((8 * k * T) / (pi * m1))

    # Entropy of the gas mixture, corrected with Planck's constant h
    S_expr = (N1 + N2) * k * (sp.log((V / (N1 + N2)) * ((4 * pi * m1 * T * k) / (2 * pi * h))**(3/2)) + 5/2)

    # Generate the problem statement
    instruction = ("Consider a two-component mixture in a container at temperature T = {T:.2f}K "
                   "with volume V = {V:.2f}m^3. Component 1 has N1 = {N1:e} particles of mass m1 = {m1:e}kg, "
                   "and component 2 has N2 = {N2:e} particles of mass m2 = {m2:e}kg. "
                   "Calculate the total internal energy U, the average velocity of component 1 particles v_avg, "
                   "and the entropy S of the gas mixture.").format(**params)

    # Solve the problem symbolically
    internal_energy = U_expr.evalf(subs=params)
    average_velocity = v_avg_expr.evalf(subs=params)
    entropy = S_expr.evalf(subs=params)

    output = ("This problem involves the calculation of internal energy, average velocity, and entropy in the field of statistical mechanics, "
              "which are important concepts for understanding the macroscopic properties of thermodynamic systems. "
              "The internal energy of the gas mixture can be calculated using the formula U = (3/2) * (N1 + N2) * k * T. "
              "The average velocity of component 1 particles within a Maxwell-Boltzmann distribution is given by "
              "v_avg = sqrt((8 * k * T) / (pi * m1)). The entropy of the gas mixture can be derived using "
              "S = (N1 + N2) * k * (log((V / (N1 + N2)) * ((4 * pi * m1 * T * k) / (2 * pi * h))^(3/2)) + 5/2). "
              "For the given parameters: N1 = {N1:e}, N2 = {N2:e}, T = {T:.2f}K, V = {V:.2f}m^3, m1 = {m1:e}kg, m2 = {m2:e}kg, "
              "the calculated internal energy is U ≈ {U:.2e} J, the average velocity for component 1 is v_avg ≈ {v_avg:.2e} m/s, "
              "and the entropy of the mixture is S ≈ {S:.2e} J/K.").format(U=internal_energy, v_avg=average_velocity, S=entropy, **params)

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = stat_mech_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('sta2.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} statistical mechanics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()