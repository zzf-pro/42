import sympy as sp
import random
import json
from scipy.constants import pi

# 1. 导入必要的库

# 2. 定义符号
# 在光子学中定义物理量的符号
f, v, λ = sp.symbols('f v λ')  # 频率，声速，波长

# 3. 生成随机参数函数
def generate_random_parameters_acoustics():
    return {
        'f': random.uniform(20, 20000),  # 频率以Hz为单位（人类可听范围）
        'v': random.uniform(340, 343)  # 空气中的声速以m/s为单位（近似值）
    }

# 4. 问题模板和解决方案
def acoustics_problem():
    params = generate_random_parameters_acoustics()

    # 声波波长的公式
    λ_expr = v / f

    # 生成问题指令
    instruction = ("一个频率为 {f:.2f} Hz 的声波在空气中传播，其中声速为 {v:.2f} m/s。"
                   "计算这个声波的波长。").format(f=params['f'], v=params['v'])

    # 符号解决问题
    wavelength = λ_expr.evalf(subs=params)

    output = ("这个问题涉及到声学中的波长计算，它是研究声波传播特性的重要工具。"
              "声波的波长是指声波在介质中相邻波峰（或波谷）之间的距离。该物理量可以通过公式 λ = v / f 来计算。"
              "其中：- v 表示声速，- f 表示声波的频率。"
              "在这个特定的问题中，我们需要计算波长 λ。根据上述公式，给定的条件是声速 v = {v:.2f} m/s，频率 f = {f:.2f} Hz，"
              "我们可以得出波长的值是 λ ≈ {wavelength:.2f} m。"
              "所以，这个声波的波长大约是 {wavelength:.2f} 米。此外，了解声波的波长有助于我们理解声波如何在不同介质中传播，"
              "也对声学设计、音乐制作等领域有着重要的应用。").format(v=params['v'], f=params['f'], wavelength=wavelength)

    # 返回问题和解决方案
    return {
        'instruction': instruction,
        'output': output
    }

# 5. 主函数
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = acoustics_problem()
        problems_and_solutions.append(problem)

    # 将问题和解决方案保存到jsonl文件
    with open('pho2.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 个声学问题和解决方案。")

# 6. 确保可读性和可重现性
# 添加注释来解释代码的每个部分

# 7. 执行
if __name__ == "__main__":
    main()