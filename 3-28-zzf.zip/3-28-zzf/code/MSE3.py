import sympy as sp
import random
import json
from scipy.constants import pi

# 1. Import Necessary Libraries

# 2. Define Symbols for Materials Science Context
# Define symbols for mechanical properties such as stress, strain, and Young's modulus
σ, ε, E = sp.symbols('σ ε E')  # Stress, strain, Young's modulus

# 3. Generate Random Parameters Function for Material Properties
def generate_random_parameters_materials():
    return {
        'E': random.uniform(100e9, 200e9),  # Young's modulus in Pascals (e.g., for steel)
        'σ': random.uniform(100e6, 500e6)   # stress in Pascals (e.g., for steel under tension)
    }

# 4. Problem Templates and Solutions for Material Sciences
def materials_problem():
    params = generate_random_parameters_materials()

    # Stress-strain relationship (Hooke's Law)
    ε_expr = σ / E

    # Generate the problem statement
    instruction = ("Given a material with Young's modulus of {E:.2e} Pa and subjected to a stress of {σ:.2e} Pa, "
                   "calculate the strain in the material.").format(E=params['E'], σ=params['σ'])

    # Solve the problem symbolically for strain
    strain = ε_expr.evalf(subs=params)

    output = ("This problem involves the basic principles of material science, particularly the stress-strain relationship "
              "known as Hooke's Law, which states that within the elastic limit of a solid material, "
              "the strain is directly proportional to the stress. Here, the modulus of elasticity (E) quantifies "
              "the material's inherent stiffness. Given the conditions that the Young's modulus is {E:.2e} Pa and the "
              "applied stress is {σ:.2e} Pa, the resulting strain is ε = {σ:.2e} / {E:.2e} = {strain:.2e}. "
              "Therefore, the strain experienced by the material is approximately {strain:.2e}.").format(
                  E=params['E'], σ=params['σ'], strain=strain
              )

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function to Generate Problems and Solutions
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = materials_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('MSE3.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} materials science problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code and its purpose

# 7. Execution
if __name__ == "__main__":
    main()