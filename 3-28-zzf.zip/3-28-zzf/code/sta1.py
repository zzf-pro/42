import sympy as sp
import random
import json
from scipy.constants import k, pi

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in statistical mechanics
N, T, U = sp.symbols('N T U')  # number of particles, temperature, internal energy

# 3. Generate Random Parameters Function
def generate_random_parameters_stat_mech():
    return {
        'N': random.randint(1, 10**24),  # number of particles
        'T': random.uniform(1, 500)  # temperature in Kelvin
    }

# 4. Problem Templates and Solutions
def stat_mech_problem():
    params = generate_random_parameters_stat_mech()

    # The internal energy of an ideal gas formula
    U_expr = (3/2) * N * k * T

    # Generate the problem statement
    instruction = ("在一个由非相互作用粒子组成的理想气体中，已知粒子数N为 {N:e}，"
                   "温度T为 {T:.2f}K，计算系统的内能。").format(N=params['N'], T=params['T'])

    # Solve the problem symbolically
    internal_energy = U_expr.evalf(subs=params)

    output = "这个问题涉及到统计力学中的内能计算，它是研究热力学系统宏观属性的重要工具。" \
        "理想气体的内能可以通过公式 U = (3/2) N k T 计算。" \
        "其中：- N 表示粒子数，- k 表示玻尔兹曼常数，- T 表示温度。" \
        f"在这个特定的问题中，我们需要计算系统的内能 U。根据上述公式，给定的条件是粒子数 N = {params['N']:e}，温度 T = {params['T']:.2f}K，" \
        f"我们可以得出系统的内能的值是 U ≈ {internal_energy:.2e} J。" \
        f"所以，这个系统的内能大约是 {internal_energy:.2e} 焦耳。此外，了解内能在统计力学中的作用有助于我们理解和预测热力学系统的行为，" \
        "这对于物理学和工程学的许多应用领域都是非常重要的。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = stat_mech_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('sta1.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} statistical mechanics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()