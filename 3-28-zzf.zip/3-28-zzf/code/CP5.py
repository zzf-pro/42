import sympy as sp
import random
import json
from scipy.constants import c

# 定义符号
m = sp.symbols('m')  # 质量

# 随机生成质量
def generate_random_mass():
    return {'m': random.uniform(1e26, 1e30)} # 质量 m，单位 kg

# 问题模板和解答生成
def nuclear_physics_problem():
    params = generate_random_mass()

    # 质能方程
    E_expr = m * c ** 2

    # 生成问题描述
    instruction = f"计算一个质量为 {params['m']:.2e} kg的粒子在核反应中释放出的能量。"

    # 计算答案
    energy = E_expr.evalf(subs=params)

    output = f"这个问题涉及到核物理中的质能方程，它是研究物质和能量的转换的重要基础" \
        "。质能方程，或 E = mc^2，是爱因斯坦相对论的核心成果，表明了质量和能量之间的等价关系。其中 E 代表能量，m 代表质量," \
        f"c 代表光速（c 的值为 {c:.2e} m/s）。在这个问题中，已知粒子的质量 m 是 {params['m']:.2e} kg, 可以通过质能方程计算出释放的能量E。" \
        f"所以，该粒子在核反应中可能释放的能量是 {energy:.2e} 焦耳。此结果是基于完全能量转换的理想情况，实际情况可能因为环境和反应类型而不同。"

    # 返回问题和答案
    return {
        'instruction': instruction,
        'output': output
    }

# 主函数
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = nuclear_physics_problem()
        problems_and_solutions.append(problem)

    # 保存问题和答案到 jsonl 文件
    with open('CP5.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 个核物理问题和解答。")

# 执行脚本
if __name__ == "__main__":
    main()