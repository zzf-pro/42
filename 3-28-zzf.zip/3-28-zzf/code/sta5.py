import sympy as sp
import random
import json
from scipy.constants import k, pi

# 1. 导入必需的库

# 2. 定义符号
# 为理想气体定义物理量的符号
N, V, T = sp.symbols('N V T')  # 分子的数量，体积，温度

# 3. 生成随机参数的函数
def generate_random_parameters_ideal_gas():
    return {
        'N': random.randint(1, 1000),       # 分子的数量，取随机整数值
        'V': random.uniform(0.1, 10.0),     # 体积，取一个合理的随机浮点数值
        'T': random.uniform(100.0, 500.0)   # 温度，单位开尔文，取一个合理的随机浮点数值
    }

# ...
# 4. 问题模板及其解答
def ideal_gas_problem():
    params = generate_random_parameters_ideal_gas()

    # 理想气体的内能计算公式 U = (3/2) * N * k * T
    U_expr = (3/2) * N * k * T

    # 生成问题陈述
    instruction = ("一个包含 {N} 个分子的理想气体在体积为 {V:.2f} 立方米的容器中，"
                   "温度为 {T:.2f} K。计算这个气体的内能。").format(**params)

    # 符号化解题
    internal_energy = U_expr.evalf(subs=params)

    output = "这个问题与理想气体的内能计算有关，这在热力学和统计力学中是一个基本概念。" \
             "这里我们使用了理想气体的内能公式 U = (3/2) * N * k * T，" \
             "其中 N 是分子的数量，k 是玻尔兹曼常数，T 是温度。" \
             f"在此问题中，给定的条件是 N = {params['N']}，V = {params['V']:.2f} 立方米，T = {params['T']:.2f} K。" \
             f"代入公式，我们可以得到内能 U ≈ {(3/2) * params['N'] * k * params['T']:.2f} 焦耳。" \
             "了解理想气体的内能对于理解相关的热力学过程非常重要。"

    # 返回问题和解答
    return {
        'instruction': instruction,
        'output': output
    }
# ...

# 5. 主函数
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = ideal_gas_problem()
        problems_and_solutions.append(problem)

    # 将问题和解答保存到jsonl文件中
    with open('sta5.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"已生成 {num_problems} 个理想气体问题及其解答。")

# 6. 确保代码的可读性和重复使用性
# 针对代码的每个部分都加上了注释

# 7. 执行
if __name__ == "__main__":
    main()