import sympy as sp
import random
import json
from scipy.constants import pi

# 1. 导入必要的库

# 2. 定义符号
# 在光子学中定义物理量的符号
ε_inf, ω_p, γ, ω = sp.symbols('ε_inf ω_p γ ω')  # 高频介电常数，等离子体频率，阻尼系数，角频率

# 3. 生成随机参数函数
def generate_random_parameters_photonics():
    return {
        'ε_inf': random.uniform(1, 10),  # 高频介电常数
        'ω_p': random.uniform(1e15, 1e16),  # 等离子体频率，单位：赫兹
        'γ': random.uniform(1e12, 1e14),  # 阻尼系数，单位：赫兹
        'ω': random.uniform(1e14, 1e16)  # 角频率，单位：赫兹
    }

# 4. 问题模板和解决方案
def photonics_problem():
    params = generate_random_parameters_photonics()

    # Drude模型公式
    ε_expr = ε_inf - ω_p**2 / (ω**2 + sp.I * γ * ω)

    # 生成问题指令
    instruction = "考虑一个使用表面等离子体共振（SPR）的传感器，该传感器包含一层金属薄膜。" \
                  "计算在特定角频率下金属的介电常数。"

    # 符号解决问题
    ε_value = ε_expr.evalf(subs=params)

    # 生成输出
    output = "这个问题涉及到计算表面等离子体共振（SPR）传感器中金属薄膜的介电常数。" \
             "金属的介电常数可以通过Drude模型 ε(ω) = ε_inf - (ω_p^2 / (ω^2 + iγω)) 来计算。" \
             f"在这个特定的问题中，给定的参数是ε_inf = {params['ε_inf']:.2f}，" \
             f"ω_p = {params['ω_p']:.2e} Hz，γ = {params['γ']:.2e} Hz，以及ω = {params['ω']:.2e} Hz，" \
             f"我们可以得出金属的介电常数的值是 ε ≈ {ε_value}。"

    # 返回问题和解决方案
    return {
        'instruction': instruction,
        'output': output
    }

# 5. 主函数
def main():
    num_problems = 1000  # 根据需要改变生成问题的数量
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = photonics_problem()
        problems_and_solutions.append(problem)

    # 将问题和解决方案保存到JSONL文件
    with open('pho5.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print("生成了 {} 个光子学问题和解决方案。".format(num_problems))

# 6. 确保可读性和可重现性
# 添加注释解释代码的每一部分

# 7. 执行
if __name__ == "__main__":
    main()