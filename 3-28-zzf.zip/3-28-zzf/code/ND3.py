import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for state variables and parameters in a nonlinear dynamics system
x, r = sp.symbols('x r')  # state variable, control parameter

# 3. Generate Random Parameters Function
def generate_random_parameters_nonlinear_dynamics():
    return {
        'x0': random.uniform(0, 1),  # initial condition for state variable
        'r': random.uniform(2.5, 4)  # control parameter in logistic map
    }

# 4. Problem Templates and Solutions
def nonlinear_dynamics_problem():
    params = generate_random_parameters_nonlinear_dynamics()

    # Logistic map formula
    logistic_map_expr = r * x * (1 - x)

    # Generate the problem statement
    instruction = ("考虑一个具有初始条件 x0 = {x0:.2f} 和控制参数 r = {r:.2f} 的逻辑映射。"
                   "计算下一个状态值。").format(x0=params['x0'], r=params['r'])

    # Solve the problem symbolically
    next_state = logistic_map_expr.evalf(subs={x: params['x0'], r: params['r']})

    output = "这个问题涉及到非线性动力学中的逻辑映射，它是研究混沌和复杂系统动力学的一个经典例子。" \
        "逻辑映射是一个简单的二次递归关系，用于模拟种群生物学中的种群增长。" \
        "公式为 x_{n+1} = r * x_n * (1 - x_n)。" \
        "其中：- r 是控制参数，- x_n 是当前状态。" \
        f"在这个特定的问题中，给定的初始条件是 x0 = {params['x0']:.2f}，控制参数 r = {params['r']:.2f}，" \
        f"下一个状态值 x1 ≈ {next_state:.2f}。" \
        "了解逻辑映射的行为有助于我们理解非线性系统如何随着时间的推移而演变，" \
        "并且可以揭示出混沌现象的存在。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = nonlinear_dynamics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('ND3.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} nonlinear dynamics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()