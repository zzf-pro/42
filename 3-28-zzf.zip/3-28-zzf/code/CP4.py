import sympy as sp
import random
import json

# 定义符号
v0, a, t = sp.symbols('v0 a t')  # 初始速度, 加速度, 时间

# 生成随机参数
def generate_random_parameters_kinematics():
    return {
        'v0': random.uniform(0, 100),  # 初始速度, m/s
        'a': random.uniform(-9.8, 9.8),  # 加速度, m/(s^2)
        't': random.uniform(0, 10)  # 时间, s
    }

# 问题模板和答案生成
def kinematics_problem():
    params = generate_random_parameters_kinematics()

    # 位移计算公式
    s_expr = v0 * t + 1/2*a * t**2

    # 生成问题描述
    instruction = ("一个初始速度为 {v0:.2f} m/s 的物体在 {a:.2f} m/s² 的加速度作用下运动了 {t:.2f} s，"
                   "计算这个物体的位移。").format(v0=params['v0'], a=params['a'], t=params['t'])

    # 计算答案
    displacement = s_expr.evalf(subs=params)

    output = "这个问题是经典物理中的一维直线运动问题。" \
        "其中位移 s 可以通过公式 s = v0*t + 1/2*a*t^2 来计算。" \
        f"在这个问题中，我们给定的初始速度 v0 = {params['v0']:.2f} m/s，加速度 a = {params['a']:.2f} m/s²，时间 t = {params['t']:.2f} s，" \
        f"将这些值代入公式，就可以得到该物体的位移为 {displacement:.2f} 米。" \
        "理解这个问题和公式，对于学习物理学中的运动定律和牛顿定律等基础知识是很有帮助的。"

    # 返回问题和答案
    return {
        'instruction': instruction,
        'output': output
    }

# 主函数
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = kinematics_problem()
        problems_and_solutions.append(problem)

    # 保存问题和答案到 jsonl 文件
    with open('CP4.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 个动力学问题和解答。")

# 执行
if __name__ == "__main__":
    main()