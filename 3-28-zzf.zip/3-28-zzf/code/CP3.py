import sympy as sp
import random
import json
from scipy.constants import c  # 导入光速常量

# 定义符号
f, λ = sp.symbols('f λ')  # 频率，波长

# 生成随机参数
def generate_random_parameters_optics():
    return {
        'f': random.uniform(430, 790)  # 光的频率，单位是THz（对应可见光的范围）
    }

# 生成问题和答案
def optics_problem():
    params = generate_random_parameters_optics()

    # 计算光波的波长的公式
    λ_expr = c / (f * 1e12)  # λ = c / f，注意单位换算

    # 生成问题描述
    instruction = ("一个频率为 {f:.2f} THz 的光在真空中传播，计算这个光的波长。"
                   ).format(f=params['f'])

    # 计算答案
    wavelength = λ_expr.evalf(subs=params)

    output = "这个问题涉及到光学中的波长计算。" \
        "光的波长是衡量光的颜色或者说频率的重要物理量。" \
        "它可以通过 λ = c / f （其中 c 为光速，f 为频率）这个公式来计算。" \
        f"在这个具体的问题中,给定的条件是光的频率 f = {params['f']:.2f} THz，" \
        f"我们可以计算得出波长 λ = {wavelength:.2f} m。" \
        f"所以，这个光的波长约为 {wavelength:.2f} m。" \
        "对光的波长的理解有助于我们理解光的颜色，以及光在各种介质中的传播，重要应用于物理学、天文学和光学工程等多个领域。"

    # 返回问题和答案
    return {
        'instruction': instruction,
        'output': output
    }

# 主函数
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = optics_problem()
        problems_and_solutions.append(problem)

    # 保存问题和答案到 jsonl 文件
    with open('CP3.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 个光学问题，以及相应的解答。")

# 运行
if __name__ == "__main__":
    main()