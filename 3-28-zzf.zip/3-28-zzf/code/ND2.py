import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in nonlinear dynamics
x, a, b = sp.symbols('x a b')  # state variable, parameters for the system

# 3. Generate Random Parameters Function
def generate_random_parameters_nonlinear_dynamics():
    return {
        'x0': random.uniform(0, 1),  # initial condition for state variable
        'a': random.uniform(0.1, 1.0),  # parameter 'a' in the system
        'b': random.uniform(0.1, 1.0)   # parameter 'b' in the system
    }

# 4. Problem Templates and Solutions
def nonlinear_dynamics_problem():
    params = generate_random_parameters_nonlinear_dynamics()

    # Example of a nonlinear dynamics equation (e.g., a modified logistic map)
    nonlinear_dynamics_expr = a * x**2 + b * (1 - x)

    # Generate the problem statement
    instruction = ("给定一个非线性动力学系统，其状态变量 x 的更新规则为 x' = a * x^2 + b * (1 - x)，" 
                   "其中参数 a = {a:.2f}，参数 b = {b:.2f}，初始条件 x0 = {x0:.2f}。"
                   "计算下一个状态值 x'。").format(x0=params['x0'], a=params['a'], b=params['b'])

    # Solve the problem symbolically
    next_state = nonlinear_dynamics_expr.evalf(subs={x: params['x0'], a: params['a'], b: params['b']})

    output = "这个问题展示了非线性动力学系统中状态变量的演化。" \
        "在这个系统中，状态变量的更新是由参数 a 和 b 控制的非线性函数。" \
        "具体的更新规则是 x' = a * x^2 + b * (1 - x)，" \
        "其中 x 是当前状态，a 和 b 是系统参数。" \
        f"在本问题中，初始状态 x0 = {params['x0']:.2f}，参数 a = {params['a']:.2f}，参数 b = {params['b']:.2f}，" \
        f"根据给定的规则，下一个状态值 x' 计算结果为 {next_state:.2f}。" \
        "这种类型的非线性方程可以用来模拟多种复杂系统的行为，包括生态系统、经济模型和其他许多自然现象。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = nonlinear_dynamics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('ND2.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} nonlinear dynamics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()