import sympy as sp
import random
import json
from scipy.constants import c  # Speed of light in vacuum

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in photonics
λ, n, v = sp.symbols('λ n v')  # wavelength, refractive index, speed of light in medium

# 3. Generate Random Parameters Function
def generate_random_parameters_photonics():
    return {
        'λ': random.uniform(400, 1550),  # wavelength in nm (common range for telecommunications)
        'n': random.uniform(1.4, 2.0)  # refractive index (common range for optical fibers)
    }

# 4. Problem Templates and Solutions
def photonics_problem():
    params = generate_random_parameters_photonics()

    # The speed of light in a medium formula
    v_expr = c / n

    # Generate the problem statement
    instruction = ("在光子学中，如果一束波长为 {λ:.2f} nm 的光在光纤材料中传播，"
                   "且光纤的折射率为 {n:.2f}，计算这束光在光纤中的传播速度。").format(λ=params['λ'], n=params['n'])

    # Solve the problem symbolically
    speed = v_expr.evalf(subs=params)

    # Convert speed to 10^8 m/s for easier interpretation
    speed_in_10_8 = speed / (10**8)

    output = "这个问题涉及到光子学中的光速计算，它是研究光在介质中传播特性的重要工具。" \
        "光在介质中的速度可以通过公式 v = c / n 计算。" \
        "其中：- c 表示光在真空中的速度，- n 表示介质的折射率。" \
        f"在这个特定的问题中，我们需要计算光速 v。根据上述公式，给定的条件是波长 λ = {params['λ']:.2f} nm，折射率 n = {params['n']:.2f}，" \
        f"我们可以得出光速的值是 v ≈ {speed_in_10_8:.2f} × 10^8 m/s。" \
        f"所以，这束光在光纤中的传播速度大约是 {speed_in_10_8:.2f} × 10^8 米/秒。" \
        "了解光在光纤中的传播速度对于优化光通信系统非常重要，影响数据传输的效率和质量。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000  # Change number of problems as needed
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = photonics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a JSONL file
    with open('pho1.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} photonics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()