import sympy as sp
import random
import json
from scipy.constants import hbar, k

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in quantum statistical mechanics
n, omega, T = sp.symbols('n omega T')  # quantum number, angular frequency, temperature

# 3. Generate Random Parameters Function
def generate_random_parameters_quantum_stat_mech():
    return {
        'n': random.randint(0, 10),  # quantum number, smaller range for demonstration
        'omega': random.uniform(1e12, 1e15),  # angular frequency in rad/s
        'T': random.uniform(1, 300)   # temperature in Kelvin
    }

# 4. Problem Templates and Solutions
def quantum_stat_mech_problem():
    params = generate_random_parameters_quantum_stat_mech()

    # Energy of the nth state of the quantum harmonic oscillator
    E_n = hbar * omega * (params['n'] + 1/2)

    # Boltzmann factor for the nth state
    boltzmann_factor = sp.exp(-E_n / (k * T))

    # Generate the problem statement
    instruction = ("Given a quantum harmonic oscillator with angular frequency omega = {omega:.2e} rad/s "
                   "and temperature T = {T:.2f}K, calculate the energy of the nth state and the corresponding "
                   "Boltzmann factor.").format(**params)

    # Solve the problem symbolically
    E_n_value = E_n.evalf(subs=params)
    boltzmann_factor_value = boltzmann_factor.evalf(subs=params)

    output = ("This problem addresses the quantum harmonic oscillator's nth state energy and Boltzmann factor in "
              "the context of quantum statistical mechanics. The energy of the nth state is given by "
              "E_n = hbar * omega * (n + 1/2) and the Boltzmann factor is exp(-E_n / (k * T)). "
              "For a system with angular frequency omega = {omega:.2e} rad/s and temperature T = {T:.2f}K, "
              "the energy of the nth state (n = {n}) is E_n = {E_n_value:.4e} J and "
              "the Boltzmann factor is approximately {boltzmann_factor_value:.4e}.").format(
                  omega=params['omega'], T=params['T'], n=params['n'],
                  E_n_value=E_n_value, boltzmann_factor_value=boltzmann_factor_value)

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000  # For demonstration purposes, we'll generate a smaller number of problems
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = quantum_stat_mech_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('sta3.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} quantum statistical mechanics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()