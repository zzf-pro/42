import sympy as sp
import random
import json
from scipy.constants import c, pi

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in high energy physics
p, E, m = sp.symbols('p E m')  # momentum, energy, mass

# 3. Generate Random Parameters Function
def generate_random_parameters_physics():
    return {
        'm': random.uniform(0.5, 3.0),  # mass in GeV/c^2 (for a range of particle masses)
        'p': random.uniform(1.0, 10.0)  # momentum in GeV/c (approximation)
    }

# 4. Problem Templates and Solutions
def physics_problem():
    params = generate_random_parameters_physics()

    # The energy of a particle formula, E = sqrt(p^2c^2 + m^2c^4)
    E_expr = sp.sqrt(p**2*c**2 + m**2*c**4)

    # Generate the problem statement
    instruction = ("一个粒子的质量为 {m:.2f} GeV/c^2，动量为 {p:.2f} GeV/c。"
                   "计算这个粒子的能量。").format(m=params['m'], p=params['p'])

    # Solve the problem symbolically
    energy = E_expr.evalf(subs={p: params['p'], m: params['m'], c: c})

    output = "这个问题涉及到高能物理中粒子的能量计算，这在粒子物理实验和理论研究中是非常重要的一环。" \
             "粒子的能量可以使用公式 E = sqrt(p^2c^2 + m^2c^4) 来计算，" \
             "其中 c 是光速，p 是粒子的动量，m 是粒子的质量。" \
             f"在这个问题中，已知粒子的动量 p = {params['p']:.2f} GeV/c 和质量 m = {params['m']:.2f} GeV/c^2，" \
             f"我们可以计算得到粒子的能量为 E = sqrt(({params['p']:.2f})^2 * (3.0 * 10^8)^2 + ({params['m']:.2f})^2 * (3.0 * 10^8)^4) ≈ {energy:.2f} J。" \
             "所以，这个粒子的能量大约是 {energy:.2f} 焦耳。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = physics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('HEP1.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} high energy physics problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()