import sympy as sp
import random
import json
from scipy.constants import c, physical_constants

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in high energy physics
m = sp.symbols('m')  # mass of the particle

# 3. Generate Random Parameters Function
def generate_random_parameters():
    return {
        'm': random.uniform(1e-30, 1e-27),  # mass of the particle in kg
    }

# 4. Problem Templates and Solutions
def high_energy_physics_problem():
    params = generate_random_parameters()

    # The energy of a particle in a high energy reaction formula
    E_expr = m * c**2

    # Convert energy to eV for more common usage in high energy physics
    J_to_eV_conversion_factor = physical_constants['joule-electron volt relationship'][0]
    E_expr_eV = E_expr * J_to_eV_conversion_factor

    # Generate the problem statement
    instruction = "在一个核反应中，有一颗质量为 {:.3e} kg 的粒子，请计算这个粒子的能量。".format(params['m'])

    # Solve the problem symbolically
    energy_J = E_expr.evalf(subs=params)
    energy_eV = E_expr_eV.evalf(subs=params)

    output = ("这个问题涉及到高能物理和核物理中的质能等价原理，这个基本原理是描述质量与能量转换的宇宙基本规律。"
              "其中，质能等价原理揭示了质量与能量之间的内在联系，这是我们研究物质和能量之间变化和转换等现象的重要依据。" 
              "能量E，质量m以及光速c之间的关系可以通过公式 E = mc² 计算。"
              "在这个具体的问题中，我们需要计算的是在核反应中粒子的能量E，"
              "给定的条件是粒子的质量m = {:.3e} kg，根据质能等价原理，我们得出其能量E的值是 {:.3e} J，或者 {:.3e} eV。"
              "理解质能等价原理，对于我们研究高能物理，例如粒子物理学，核物理学等领域的科学问题有根本的意义。").format(params['m'], energy_J, energy_eV)

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = high_energy_physics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('HEP5.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 道高能物理问题和对应的解答。")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()