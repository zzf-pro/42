import sympy as sp
import random
import json
from scipy.constants import c, pi

# 1. 导入必要的库

# 2. 定义符号
# 定义光子学中物理量的符号
n_0, delta_n, Lambda, m, lambda_wave = sp.symbols('n_0 delta_n Lambda m lambda_wave')

# 3. 生成随机参数函数
def generate_random_parameters_photonics():
    return {
        'n_0': 1.5,  # 平均折射率
        'delta_n': 0.1,  # 折射率变化的幅度
        'Lambda': 500e-9  # 光子晶体的周期，单位转换为米
    }

# 4. 问题模板和解决方案
def photonics_problem():
    params = generate_random_parameters_photonics()

    # 布拉格条件 (Bragg's condition)
    bragg_condition = sp.Eq(2 * n_0 * Lambda, m * lambda_wave)

    # 解决布拉格条件，找到波长 lambda_wave
    solutions = sp.solve(bragg_condition.subs(params), lambda_wave)

    # 使用第一阶布拉格散射 m = 1
    lambda_solution = solutions[0].subs(m, 1)

    # 光速
    speed_of_light = c

    # 边缘频率的计算
    edge_frequency = speed_of_light / lambda_solution

    # 生成问题指令
    instruction = "一个光子晶体具有一维周期性结构，折射率随位置变化可以用余弦函数描述。" \
                  "计算这个光子晶体的带隙边缘频率。"

    # 生成输出
    output = "这个问题涉及到计算光子晶体的带隙边缘频率。" \
             "带隙边缘频率可以使用布拉格条件 2 n_0 Lambda = m lambda_wave 来计算，" \
             "其中 n_0 是平均折射率，Lambda 是光子晶体的周期，m 是布拉格级数，lambda_wave 是波长。" \
             "在这个特定的问题中，给定的参数是平均折射率 n_0 = 1.5，折射率变化幅度 delta_n = 0.1，" \
             "以及周期 Lambda = 500 纳米。" \
             "通过解决布拉格条件，我们找到第一阶带隙边缘的波长 lambda_wave，然后通过公式 f = c / lambda_wave，" \
             "我们可以计算出边缘频率 f ≈ {:.2e} Hz。".format(edge_frequency.evalf())

    # 返回问题和解决方案
    return {
        'instruction': instruction,
        'output': output
    }

# 5. 主函数
def main():
    num_problems = 1000  # 根据需要生成问题的数量
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = photonics_problem()
        problems_and_solutions.append(problem)

    # 将问题和解决方案保存到JSONL文件
    with open('pho3.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 个光子学问题和解决方案。")

# 6. 确保可读性和可重现性
# 添加注释来解释代码的每个部分

# 7. 执行
if __name__ == "__main__":
    main()