import sympy as sp
import json
import random
from scipy.constants import year, mega

# 1. Import Necessary Libraries
# SymPy for symbolic mathematics, random for generating random parameters

# 2. Define Symbols
# Define symbols for the Hubble constant (H0) and the age of the universe (T)
H0, T = sp.symbols('H0 T')  # H0: Hubble constant, T: age of the universe


# 3. Generate Random Parameters Function
def generate_random_hubble_constant():
    # Generate a random Hubble constant in the range of observations
    return random.uniform(50, 100)  # km/s/Mpc


# 4. Problem Templates and Solutions
def generate_cosmology_problem():
    # Generate random Hubble constant parameter
    hubble_constant = generate_random_hubble_constant()

    # Age of the universe calculation formula in Gyr (gigayears)
    # Conversion factors: 1 Mpc = mega parsecs, 1 Gyr = 10^9 years
    # Hubble constant units: km/s/Mpc, so we convert to s^-1
    # Using Hubble's law: v = H0 * d, and for v = c at the edge of the observable universe
    T_expr = 1 / H0 * mega * year * 10 ** 9  # H0 is in s^-1, so T will be in years

    # Solve the problem symbolically
    age_of_universe = T_expr.evalf(subs={H0: hubble_constant / (mega * year)})

    # Problem and solution template
    problem = {
        "category": "宇宙学",
        "instruction": f"给定哈勃常数为 {hubble_constant} km/s/Mpc，计算宇宙的年龄。",
        "output": f"宇宙学中，宇宙的年龄可以通过哈勃常数估计。哈勃常数描述了宇宙膨胀的速率。"
                  f"宇宙年龄的估计公式为 T = 1 / H0，其中 H0 是哈勃常数。"
                  f"给定哈勃常数为 {hubble_constant} km/s/Mpc，宇宙的年龄估计为 {age_of_universe:.2e} 年。"
    }

    return problem


# 5. Main Function
def main():
    num_problems = 1000  # Number of problems to generate
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = generate_cosmology_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a JSONL file
    with open('cos1.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} cosmology problems and solutions.")


# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()
#!/usr/bin/python
# -*- coding:utf-8 -*-
