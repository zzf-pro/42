import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in quantum field theory
g, m1, m2, q = sp.symbols('g m1 m2 q')  # coupling constant, masses of particles, transferred momentum

# 3. Generate Random Parameters Function
def generate_random_parameters_qft():
    return {
        'g': random.uniform(0.1, 1.0),    # coupling constant (dimensionless)
        'm1': random.uniform(0.1, 10.0),  # mass of the first particle in GeV/c^2
        'm2': random.uniform(0.1, 10.0),  # mass of the second particle in GeV/c^2
        'q': random.uniform(0.1, 5.0)     # transferred momentum in GeV/c
    }

# 4. Problem Templates and Solutions
def qft_problem():
    params = generate_random_parameters_qft()

    # The interaction energy for virtual particle exchange formula
    E_interaction_expr = g**2 / (8 * sp.pi**2 * q**2)

    # Generate the problem statement
    instruction = ("在量子场论中，两个质量分别为 {m1:.2f} GeV/c² 和 {m2:.2f} GeV/c² 的粒子，"
                   "通过交换一个传递动量为 {q:.2f} GeV/c 的虚粒子相互作用。"
                   "假设耦合常数为 {g:.2f}，计算相互作用能量。").format(
                       m1=params['m1'], m2=params['m2'], q=params['q'], g=params['g'])

    # Solve the problem symbolically
    interaction_energy = E_interaction_expr.evalf(subs=params)

    output = "这个问题涉及到量子场论中的虚粒子交换相互作用能量的计算，它是研究基本粒子相互作用的重要工具。" \
        "相互作用能量可以通过公式 E_interaction = g² / (8π²q²) 计算。" \
        "其中：- g 表示耦合常数，- q 表示传递动量。" \
        f"在这个特定的问题中，给定的条件是耦合常数 g = {params['g']:.2f}，传递动量 q = {params['q']:.2f} GeV/c，" \
        f"我们可以得出相互作用能量的值是 E_interaction ≈ {interaction_energy:.2e} (GeV)^2/c⁴。" \
        "了解这种相互作用能量对于理解粒子物理实验中观察到的现象至关重要，特别是在高能粒子碰撞中。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 10  # Number of problems to generate, adjust as needed
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = qft_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a json file
    with open('qum2.json', 'w', encoding='utf-8') as f:
        json.dump(problems_and_solutions, f, ensure_ascii=False, indent=4)

    print(f"Generated {num_problems} quantum field theory problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()