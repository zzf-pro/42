import sympy as sp
import random
import json
from scipy.constants import pi

# 定义物理量符号
ρ, E, σ = sp.symbols('ρ E σ')  # 密度，弹性模量，应力

# 生成随机参数函数
def generate_random_parameters_materials():
    return {
        'ρ': random.uniform(1000, 10000),  # density in kg/m^3 (approximation for metals)
        'E': random.uniform(10^9, 10^12)  # elastic modulus in Pa (approximation for metals)
    }

# 问题模版及解答
def materials_problem():
    params = generate_random_parameters_materials()

    # Stress formula
    σ_expr = E / ρ

    # 生成问题描述
    instruction = ("一种金属的密度为 {ρ:.2f} kg/m^3，弹性模量为 {E:.2f} Pa。"
                   "计算这种金属的应力。").format(ρ=params['ρ'], E=params['E'])

    # 符号化解问题
    stress = σ_expr.evalf(subs=params)

    output = "这个问题涉及到材料科学中的应力计算，这是研究材料失效模式的重要性质。" \
        "材料的应力是指材料在受到外力作用时每单位面积所承受的力。该物理量可以通过公式 σ = E / ρ 计算。" \
        "其中：- E 表示弹性模量,- ρ 表示材料的密度。" \
        f"在这个特定的问题中，我们需要计算应力 σ。根据上述公式，给定的条件是弹性模量 E = {params['E']:.2f} Pa，密度 ρ = {params['ρ']:.2f} kg/m^3，" \
        f"我们可以得出应力的值是 σ ≈ {params['E']:.2f} / {params['ρ']:.2f} ≈ {stress:.2f} Pa。" \
        f"所以，这种金属的应力大约是 {stress:.2f} 巴。材料的应力可以帮助我们了解该材料在承受力时的性质，" \
        "这对于工程设计、材料选择等领域有着重要的应用。"

    # 返回问题和答案
    return {
        'instruction': instruction,
        'output': output
    }

# 主函数
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = materials_problem()
        problems_and_solutions.append(problem)

    # 保存问题和答案到jsonl文件
    with open('MSE4.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 材料科学问题及答案。")

if __name__ == "__main__":
    main()