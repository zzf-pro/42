import sympy as sp
import random
import json
from scipy.constants import c, physical_constants

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in high energy physics
m = sp.symbols('m')  # mass of the particle

# 3. Generate Random Parameters Function
def generate_random_parameters():
    return {
        'm': random.uniform(1e-30, 1e-27),  # mass of the particle in kg
    }

# 4. Problem Templates and Solutions
def high_energy_physics_problem():
    params = generate_random_parameters()

    # The energy of a particle in a high energy reaction formula
    E_expr = m * c**2

    # Convert energy to eV for more common usage in high energy physics
    J_to_eV_conversion_factor = physical_constants['joule-electron volt relationship'][0]
    E_expr_eV = E_expr * J_to_eV_conversion_factor

    # Generate the problem statement
    instruction = "在一个高能反应中，有一颗质量为 {m:.3e} kg 的粒子，计算这个粒子的能量。".format(m=params['m'])

    # Solve the problem symbolically
    energy_J = E_expr.evalf(subs=params)
    energy_eV = E_expr_eV.evalf(subs=params)

    output = ("这个问题涉及到高能物理中的质能等价原则。质能等价原则是爱因斯坦提出的，描述了质量和能量之间的关系。"
              "该物理量可以通过公式 E = mc² 计算。其中："
              "- m 表示粒子的质量，"
              "- c 表示光速。"
              f"在这个特定问题中，我们需要计算能量 E。根据上述公式，给定的条件是质量 m = {params['m']:.3e} kg，"
              f"我们可以得出能量 E 的值是 {energy_J:.3e} J 或是 {energy_eV:.3e} eV。"
              "质能等价原则在高能物理中的应用至关重要，因为它解释了为何粒子在高能反应中可以产生如此大的能量。")

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = high_energy_physics_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('HEP4.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 道高能物理问题和对应的解答。")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()