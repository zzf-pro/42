import sympy as sp
import random
import json

# 1. Import Necessary Libraries

# Define the symbols for quantum field quantities
a, ad, k, ω = sp.symbols('a ad k ω')  # annihilation operator, creation operator, wave vector, angular frequency

# 3. Generate Random Parameters Function
def generate_random_parameters_qft():
    return {
        'k': random.uniform(0.1, 10.0),  # wave vector in 1/m
        'ω': random.uniform(0.1, 10.0)   # angular frequency in s^-1
    }

# 4. Problem Templates and Solutions
def qft_quantization_problem():
    params = generate_random_parameters_qft()

    # The commutation relation for creation and annihilation operators
    commutation_relation = sp.Eq(a * ad - ad * a, 1)

    # Generate the problem statement
    instruction = ("考虑一个自由标量场的量子化，其中粒子的产生算符(ad)和湮灭算符(a)满足对易关系 [a, ad] = 1。"
                   "已知波矢k = {k:.2f} 1/m 和角频率ω = {ω:.2f} s^-1，"
                   "写出与这些参数相关的场算符Φ和Π的表达式。").format(
                       k=params['k'], ω=params['ω'])

    # Symbolically represent the field operators
    Φ = 1/sp.sqrt(2*ω) * (a + ad)
    Π = -sp.I*sp.sqrt(ω/2) * (a - ad)

    # Construct the output with the expressions for Φ and Π
    output = "这个问题涉及到场的量子化和粒子的产生/湮灭算符。" \
        "在量子场论中，场算符Φ和动量算符Π可以通过产生算符(ad)和湮灭算符(a)来表示。" \
        "场算符Φ可以表示为 Φ = (1/√(2ω)) * (a + ad)，" \
        "动量算符Π可以表示为 Π = -i√(ω/2) * (a - ad)，其中 i 是虚数单位。" \
        f"在这个特定的问题中，波矢 k = {params['k']:.2f} 1/m 和角频率 ω = {params['ω']:.2f} s^-1，" \
        f"场算符Φ = (1/√({2*params['ω']:.2f})) * (a + ad)，" \
        f"动量算符Π = -i√({params['ω']:.2f}/2) * (a - ad)。" \
        "这些算符在量子场论中至关重要，因为它们用于描述粒子的产生和湮灭，而粒子的行为是通过这些场算符来量化的。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 10  # Number of problems to generate, adjust as needed
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = qft_quantization_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a json file
    with open('qum4.json', 'w', encoding='utf-8') as f:
        json.dump(problems_and_solutions, f, ensure_ascii=False, indent=4)

    print(f"Generated {num_problems} quantum field theory quantization problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()