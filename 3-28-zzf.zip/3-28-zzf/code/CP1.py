import numpy as np
from random import uniform
import json
from scipy.integrate import quad

# Configurable parameters
FUNC_MIN = -10.0
FUNC_MAX = 10.0
DOMAIN_MIN = -10
DOMAIN_MAX = 10

def generate_random_function_and_domain():
    """ Generates a random function f(x) = ax^2 + bx + c and its domain [x1,x2] """
    a = uniform(FUNC_MIN, FUNC_MAX)
    b = uniform(FUNC_MIN, FUNC_MAX)
    c = uniform(FUNC_MIN, FUNC_MAX)
    x1 = uniform(DOMAIN_MIN, DOMAIN_MAX)
    x2 = uniform(x1, DOMAIN_MAX)  # Ensure x1 < x2
    return a, b, c, x1, x2

def computational_physics_problem():
    a, b, c, x1, x2 = generate_random_function_and_domain()

    # Function in question
    f = lambda x: a*x*x + b*x + c

    # Calculate result
    result, error = quad(f, x1, x2)
    result = round(result, 2)  # Round to 2 decimal places for readability

    # Problem and solution
    problem = {
        "instruction": f"请计算在{x1}到{x2}区间内函数f(x)={a}x² + {b}x + {c}的积分值。",
        "output": f"该问题涉及到计算物理中的数值积分技术，主要通过数值方法去近似解决复杂的定积分问题。定积分在物理学中有广泛的应用，例如计算物体的速度、位移，或者在电磁学中计算电场、磁场等。经计算，函数f(x)={a}x² + {b}x + {c}在{x1}到{x2}区间内的积分值近似为{result}。"
    }

    return problem

def generate_problems_and_write_to_file(num_problems):
    # Generate problems
    problems = [computational_physics_problem() for _ in range(num_problems)]

    # Save to file
    with open("CP1.json", 'w') as f:
        json.dump(problems, f, indent=4)

    print(f"成功生成了{num_problems}个计算物理问题模板，并已写入到文件“computational_physics_problems_and_solutions.json”中。")

# Main function
if __name__ == "__main__":
    generate_problems_and_write_to_file(1000)