import sympy as sp
import random
import json
from scipy.constants import pi

# 1. Import Necessary Libraries

# 2. Define Symbols
d, r, V, m, rho = sp.symbols('d r V m rho')  # diameter, radius, volume, mass, density

# 3. Generate Random Parameters Function
def generate_random_parameters_nanotechnology():
    return {
        'd': random.uniform(1e-9, 100e-9),  # diameter in meters (range for nanoparticles)
        'rho': random.uniform(1000, 5000),  # density in kg/m^3
    }

# 4. Problem Templates and Solutions
def nanotechnology_problem():
    params = generate_random_parameters_nanotechnology()
    r_expr = d / 2  # Convert diameter to radius
    V_expr = (4/3) * pi * r**3  # Volume of a sphere formula
    m_expr = rho * V  # Mass formula

    # Generate the problem statement
    instruction = ("一个完美的球形纳米颗粒，其直径为 {d:.2e} 米，材料密度为 {rho:.2e} 千克/立方米，"
                   "计算这个纳米颗粒的体积和质量。").format(d=params['d'], rho=params['rho'])

    # Solve the problem symbolically
    volume = V_expr.subs(r, r_expr.subs(d, params['d'])).evalf()
    mass = m_expr.subs({V: volume, rho: params['rho']}).evalf()

    output = "这个问题涉及到纳米技术中的纳米颗粒体积和质量的计算，这是研究纳米材料特性的一个重要方面。" \
        "纳米颗粒的体积可以通过公式 V = (4/3)πr^3 来计算，其中 r 代表颗粒的半径。" \
        "质量可以使用公式 m = ρV 来计算，其中 ρ 代表材料的密度。" \
        f"在这个问题中，已知纳米颗粒的直径为 {params['d']:.2e} 米，密度为 {params['rho']:.2e} 千克/立方米，" \
        f"我们可以计算出体积为 V ≈ {volume:.2e} 立方米，质量为 m ≈ {mass:.2e} 千克。" \
        "了解这些物理量对于开发新的纳米材料和纳米技术应用，如药物输送系统和纳米级催化剂，是非常重要的。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000  # Change this number to the desired amount of problems
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = nanotechnology_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('nan3.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} nanotechnology problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()