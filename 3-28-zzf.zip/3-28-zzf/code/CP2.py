import sympy as sp
import random
import json

# 1. Define Symbols
# Define symbols for physical quantities in oscillatory physics
m, k = sp.symbols('m k')  # mass, spring constant

# 2. Generate Random Parameters Function
def generate_random_parameters_oscillation():
    return {
        'm': random.uniform(0.1, 10.0),  # Mass in kg
        'k': random.uniform(0.1, 10.0)  # Spring constant in N/m
    }

# 3. Problem Templates and Solutions
def oscillation_problem():
    params = generate_random_parameters_oscillation()

    # The natural frequency of a harmonic oscillator formula
    ω_expr = sp.sqrt(k / m)

    # Generate the problem statement
    instruction = ("一个简谐振子的质量为 {m:.2f} kg，弹簧的劲度系数为 {k:.2f} N/m。"
                   "求该振子的谐振频率。").format(m=params['m'], k=params['k'])

    # Solve the problem symbolically
    resonance_frequency = ω_expr.evalf(subs=params)

    output = "这个问题涉及到振动力学中的谐振频率计算，它是研究物体振动性质的重要工具。" \
        "简谐振子的谐振频率是指振子在没有受到阻力时自由振动的频率，该物理量可以通过公式 ω = √(k / m) 计算。" \
        "其中：- k 表示弹簧的劲度系数，- m 表示振子的质量。" \
        f"在这个特定的问题中，我们需要计算谐振频率 ω。根据上述公式，给定的条件是质量 m = {params['m']:.2f} kg，劲度系数 k = {params['k']:.2f} N/m，" \
        f"我们可以得出谐振频率的值是 ω ≈ √({params['k']:.2f} / {params['m']:.2f}) ≈ {resonance_frequency:.2f} rad/s。" \
        f"所以，这个简谐振子的谐振频率大约是 {resonance_frequency:.2f} rad/s。此外，了解振子的谐振频率有助于我们理解物体的振动性质，" \
        "也对于设计振动系统、测量物体的动态特性等领域有着重要的应用。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 4. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = oscillation_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('CP2.json', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} oscillatory physics problems and solutions.")

# 5. Execution
if __name__ == "__main__":
    main()