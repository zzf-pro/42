import sympy as sp
import random
import json

# 定义电阻率的符号
rho = sp.symbols('rho')

# 生成电阻率的随机参数的函数，采用量子线的现实范围
def generate_random_parameters():
    return {
        'rho': random.uniform(1e-8, 1e-6),  # 电阻率，单位欧姆·米
    }

# 生成问题模板的函数
def generate_problem_template():
    params = generate_random_parameters()

    # 计算电导率的公式
    sigma_expr = 1 / rho

    # 问题的指令
    instruction = "已知一个量子线的电阻率为 {rho:.2e} Ω·m，计算其电导率。".format(rho=params['rho'])

    # 计算解答
    sigma_value = sigma_expr.evalf(subs=params)

    # 输出解释
    output = "这个问题涉及到纳米技术领域中电导率的概念，它是理解量子线中电子传输的基本工具。" \
             "电导率是衡量材料导电能力的量度。它可以用公式 σ = 1 / ρ 来计算。" \
             "其中：\n" \
             "  - ρ 代表电阻率。\n\n" \
             "在这个具体问题中，已知电阻率 ρ = {rho:.2e} Ω·m，电导率 σ 可以计算为 {sigma:.2e} S/m。" \
             "因此，这个量子线的电导率大约是 {sigma:.2e} 西门子每米。" \
             "此外，了解电导率对于设计如晶体管、传感器和其他电子元件等纳米技术应用至关重要。".format(rho=params['rho'], sigma=sigma_value)

    # 返回问题和解答的字典
    return {
        'instruction': instruction,
        'output': output
    }

# 将问题保存到JSONL文件的函数
def save_problems_to_file(problems, filename):
    with open(filename, 'w', encoding='utf-8') as file:
        for problem in problems:
            file.write(json.dumps(problem, ensure_ascii=False) + '\n')

# 主函数，用于生成一定数量的问题模板
def main():
    num_problems = 1000  # 更改此值以生成更多或更少的问题
    problems = [generate_problem_template() for _ in range(num_problems)]
    save_problems_to_file(problems, 'nan2.jsonl')

    print(f"生成了 {num_problems} 个有关计算电导率的纳米技术问题。")

# 执行主函数
if __name__ == "__main__":
    main()