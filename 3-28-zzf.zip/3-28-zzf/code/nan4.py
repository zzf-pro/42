import sympy as sp
import random
import json
from scipy.constants import pi

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in Nanotechnology
d, r, rho, V, m = sp.symbols('d r rho V m')  # diameter, radius, density, volume, mass


# 3. Generate Random Parameters Function
def generate_random_parameters_nanotechnology():
    return {
        'd': random.uniform(1e-9, 100e-9),  # diameter in meters (range for nanoparticles)
        'rho': random.uniform(1e3, 22e3),  # density in kg/m^3 (assumed range for common materials)
    }


# 4. Problem Templates and Solutions
def nanotechnology_problem():
    params = generate_random_parameters_nanotechnology()

    # Convert diameter to radius
    params['r'] = params['d'] / 2

    # The volume of a sphere formula
    V_expr = 4 / 3 * pi * r ** 3

    # The mass of the nanoparticle formula
    m_expr = rho * V

    # Generate the problem statement
    instruction = ("一个球形纳米颗粒的直径为 {d:.2e} 米，材料的密度为 {rho:.2e} 千克/立方米。"
                   "计算这个纳米颗粒的质量。").format(**params)

    # Solve the problem symbolically
    volume = V_expr.subs(r, params['r']).evalf()
    mass = m_expr.subs({rho: params['rho'], V: volume}).evalf()

    output = "这个问题涉及到纳米技术领域中的纳米颗粒质量计算，它是研究纳米颗粒特性的重要工具。" \
             "纳米颗粒的质量可以通过公式 \( m = \\rho V \) 计算，其中 \( V = \\frac{4}{3} \pi r^3 \) 是纳米颗粒的体积，" \
             "r 是纳米颗粒的半径，\( \\rho \) 是材料的密度。" \
             f"在这个特定的问题中，给定的条件是直径 d = {params['d']:.2e} 米，密度 rho = {params['rho']:.2e} 千克/立方米，" \
             f"我们可以得出纳米颗粒的质量 m ≈ {mass:.2e} 千克。" \
             "了解这个质量对于设计纳米级药物递送系统、感测器件和催化剂等是至关重要的。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }


# 5. Main Function
def main():
    num_problems = 1000  # Change this number to the desired amount of problems
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = nanotechnology_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    with open('nan4.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"Generated {num_problems} nanotechnology problems and solutions.")


# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()