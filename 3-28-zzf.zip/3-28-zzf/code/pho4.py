import sympy as sp
import random
import json
from scipy.constants import c, pi

# 1. 导入必要的库

# 2. 定义符号
# 在光子学中定义物理量的符号
λ, n_2, P, A_eff, L, Δphi = sp.symbols('λ n_2 P A_eff L Δphi')  # 波长，克尔系数，功率，有效模式面积，传播距离，非线性相位移动

# 3. 生成随机参数函数
def generate_random_parameters_photonics():
    return {
        'λ': random.uniform(800e-9, 1600e-9),  # 波长在800nm到1600nm之间，常见于光通信
        'n_2': random.uniform(2e-20, 3e-20),  # 克尔系数，单位是 m^2/W
        'P': random.uniform(1e-3, 1e-2),  # 功率，单位是 W
        'A_eff': random.uniform(10e-12, 15e-12),  # 有效模式面积，单位是 m^2
        'L': random.uniform(0.1, 2.0),  # 传播距离，单位是 m
    }

# 4. 问题模板和解决方案
def photonics_problem():
    params = generate_random_parameters_photonics()

    # 非线性相位移动公式
    Δphi_expr = (2 * pi / λ) * n_2 * (P / A_eff) * L

    # 生成问题指令
    instruction = ("考虑一种具有非线性克尔效应的光波导，其克尔系数为 n_2，"
                   "当一束功率为 P 的连续波激光通过该光波导时，非线性相位移动 Δphi 是多少？"
                   "假设光波导的有效模式面积 A_eff 已知。")

    # 解决问题
    Δphi_solution = Δphi_expr.evalf(subs=params)

    # 生成输出
    output = ("这个问题涉及到光波导中克尔非线性效应引起的非线性相位移动。"
              "非线性相位移动可以通过公式 Δphi = (2 * pi / λ) * n_2 * (P / A_eff) * L 来计算。"
              "在这个特定的问题中，给定波长 λ = {λ:e} m，克尔系数 n_2 = {n_2:e} m^2/W，"
              "功率 P = {P:e} W，有效模式面积 A_eff = {A_eff:e} m^2，以及传播距离 L = {L} m，"
              "我们可以得出非线性相位移动的值是 Δphi ≈ {Δphi:.2e} rad。"
              "非线性相位移动在光学信号处理和光通信中有重要应用。").format(
                  λ=params['λ'], n_2=params['n_2'], P=params['P'],
                  A_eff=params['A_eff'], L=params['L'], Δphi=Δphi_solution)

    # 返回问题和解决方案
    return {
        'instruction': instruction,
        'output': output
    }

# 5. 主函数
def main():
    num_problems = 1000  # 根据需要改变生成问题的数量
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = photonics_problem()
        problems_and_solutions.append(problem)

    # 将问题和解决方案保存到JSONL文件
    with open('pho4.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"生成了 {num_problems} 个光子学问题和解决方案。")

# 6. 确保可读性和可重现性
# 添加注释解释代码的每一部分

# 7. 执行
if __name__ == "__main__":
    main()