import sympy as sp
import random
import json
from scipy.constants import pi

# 1. Import Necessary Libraries

# 2. Define Symbols
# Define symbols for physical quantities in nanotechnology
d, r, A = sp.symbols('d r A')  # diameter, radius, surface area

# 3. Generate Random Parameters Function
def generate_random_parameters_nanotechnology():
    return {
        'd': random.uniform(1e-9, 1e-7),  # diameter in meters (range for nanoparticles)
    }

# 4. Problem Templates and Solutions
def nanotechnology_problem():
    params = generate_random_parameters_nanotechnology()

    # The surface area of a sphere formula
    r_expr = d / 2
    A_expr = 4 * pi * r_expr**2

    # Generate the problem statement
    instruction = ("给定直径为 {d:.2e} m 的纳米粒子，计算其表面积。").format(d=params['d'])

    # Solve the problem symbolically
    surface_area = A_expr.evalf(subs={d: params['d']})

    output = "这个问题涉及到纳米技术中的表面积计算，它是研究纳米粒子特性的重要工具。" \
        "纳米粒子的表面积是指粒子外表层的总面积。该物理量可以通过公式 A = 4πr^2 计算。" \
        "其中：- r 表示纳米粒子的半径，- d 表示纳米粒子的直径。" \
        f"在这个特定的问题中，我们需要计算表面积 A。根据上述公式，给定的条件是直径 d = {params['d']:.2e} m，" \
        f"我们可以得出表面积的值是 A ≈ {surface_area:.2e} m²。" \
        f"所以，这个纳米粒子的表面积大约是 {surface_area:.2e} 平方米。此外，了解纳米粒子的表面积对于设计和应用如药物输送、催化剂和传感器等领域的纳米结构至关重要。"

    # Return problem and solution
    return {
        'instruction': instruction,
        'output': output
    }

# 5. Main Function
def main():
    num_problems = 1000
    problems_and_solutions = []

    for _ in range(num_problems):
        problem = nanotechnology_problem()
        problems_and_solutions.append(problem)

    # Save problems and solutions into a jsonl file
    i=0
    with open('nan1.jsonl', 'w', encoding='utf-8') as f:
        for item in problems_and_solutions:
            i += 1
            if i != 1000:
                f.write(json.dumps(item, ensure_ascii=False) + ',\n')
            else:
                f.write(json.dumps(item, ensure_ascii=False))

    print(f"Generated {num_problems} nanotechnology problems and solutions.")

# 6. Ensure Readability and Reproducibility
# Comments are added to explain each part of the code

# 7. Execution
if __name__ == "__main__":
    main()